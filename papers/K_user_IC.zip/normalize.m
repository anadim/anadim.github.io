function [ Qlite ] = normalize(X)
for i = 1:size(X,3)
Qlite(:,:,i) = X(:,:,i)./norm(X(:,:,i));
end
end


function [V U] = nuclear_IA_K_user(H, U, epsilon, iter)

[Mr, Mt, K, K] = size(H); % obtain problem parameters
dk = size(U,2);

for i = 1:2*iter % 2 turns at each iteration
        
    cvx_begin

    if mod(i,2) == 1 % at odd turns, we optimze over the beamformers
        clear V J f_cost A
        variable V(Mt,dk,K) 
    elseif mod(i,2) == 0 % at even turns, we optimze over the zeroforcers
        clear U J f_cost A
        variable U(Mr,dk,K)
    end
    %%% the following defines the cost function %%%
    J = zeros(dk, (K-1)*dk, K); %initialize the interference matrix
    J = cvx(J); % make it a cvx variable
    f_cost = cvx(0); % initialize cost function
    for k = 1:K
        A = cvx(zeros(dk,1));
        for l = [1:k-1 k+1:K]
            A = [A U(:,:,k)'*H(:,:,l,k)*V(:,:,l)]; %each term is one interference block
        end
        J(:,:,k) = A(:,2:end);
        f_cost = f_cost+norm_nuc(J(:,:,k)); % the cost function is the sum of interference singular values
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%% nuclear norm minimization %%%%%%%%%%%
    minimize f_cost
    subject to
    for k = 1:K
        lambda_min(U(:,:,k)'*H(:,:,k,k)*V(:,:,k)) >= epsilon % minimum eigenvalue constraint
        U(:,:,k)'*H(:,:,k,k)*V(:,:,k) == semidefinite(dk) % nonnegative definite constraint
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    cvx_end
    
end

end




function [ Qlite ] = orthogonalize(X)
for i = 1:size(X,3)
[Q(:,:,i) R] = qr(X(:,:,i));
r = rank(R);
Qlite(:,:,i)=[Q(:,1:r,i) zeros(size(X,1),size(X,2)-r)];
end
end


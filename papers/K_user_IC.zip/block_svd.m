function [S_eig J_eig] = block_svd(U, H, V)

K = size(V,3);
d = size(V,2);

J = zeros(d, (K-1)*d, K);
for k = 1:K
    A = zeros(d,1);
    for l = [1:k-1 k+1:K]
        A = [A U(:,:,k)'*H(:,:,l,k)*V(:,:,l)];
    end
    J(:,:,k) = A(:,2:end);
    
    S(:,:,k) = U(:,:,k)'*H(:,:,k,k)*V(:,:,k);
    
    S_eig(:,k) = svd(S(:,:,k));
    J_eig(:,k) = svd(J(:,:,k));
end

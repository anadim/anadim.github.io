function [ V, U ] = leakage_minimization_K_user(H, V, iter)

[Mr, Mt, K, K] = size(H); % obtain problem parameters
dk = size(V,2);

for i = 1:iter
    clear U Qv U_eig % clear values used in the following
    Qv = zeros(Mr, (K-1)*dk, K); % initialize the interference covariance
    for k = 1:K
        A = zeros(Mr,1);
        for l = [1:k-1 k+1:K] % you get interference from all l\ne k users
            A = [A H(:,:,l,k)*V(:,:,l)]; % build the interference covariance
        end
        Qv(:,:,k) = A(:,2:end);
        for kk = 1:K
            [U_eig, temp] = eig(Qv(:,:,k)*Qv(:,:,k)'); % compute tzeroforcers
            U(:,:,k) = U_eig(:,1:dk);
        end
        
    end
    clear V Qu V_eig % clear values used in the following
    Qu = zeros(Mt, (K-1)*dk, K); % initialize reciprocal interference covariance
    for k = 1:K
        A = zeros(Mt,1);
        for l = [1:k-1 k+1:K]
            A = [A H(:,:,k,l)'*U(:,:,l)]; % build reciprocal interference covariance
        end
        Qu(:,:,k) = A(:,2:end);
        for kk = 1:K
            [V_eig, temp] = eig(Qu(:,:,k)*Qu(:,:,k)'); % compute beamformers
            V(:,:,k) = V_eig(:,1:dk);
        end
    end
end

end


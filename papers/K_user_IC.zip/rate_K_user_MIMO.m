function R = rate_K_user_MIMO(K, d, P_stream, U, H, V, is_real)
R = 0;

for k = 1:K
    A = zeros(d,1);
    for l = [1:k-1 k+1:K]
        A = [A U(:,:,k)'*H(:,:,l,k)*V(:,:,l)];
    end
    J(:,:,k) = A(:,2:end);
    S(:,:,k) = U(:,:,k)'*H(:,:,k,k)*V(:,:,k);
    
    R = R + log2(det(eye(size(J,1))+(eye(size(J,1))+J(:,:,k)*J(:,:,k)')^-1*S(:,:,k)*S(:,:,k)'));
end

if is_real == 1
    R = R/2;
end

end


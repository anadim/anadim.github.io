%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        K-user IC simulation       %
%     Dimitris S. Papailiopoulos    %
%            March 2011             %
% University of Southern California %
%             ver 1.0               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all
% close all

cvx_quiet(true) % make cvx silent

MC = 2; % #Monte Carlo Simulations
K = 5; % number of users
dk = 2; % requested DoF/user
Mt = 9; % #Tx antennas
Mr = 3; % #Rx antennas
iter_nucnorm = 100; % #iterations of nuclear approximation
iter_leakmin = 1; % #iterations of leakage minimization
iter_maxsinr = 1; % #iterations of max-SINR
epsilon = 0.1; % the epsilon parameter of our approximation
Pdb = [0 40 80]; % transmit power in dB
DoF_accuracy = 10^-5;

d_start = 2; % select from which DoF/user we wish to begin

display([num2str(K),'-user Interference Channel Mr = ', num2str(Mr),', Mt = ',num2str(Mt) '.'])
display([' ']);
for d = d_start:dk
    for p = 1:length(Pdb)
        display(['Running ',num2str(MC), ' Monte Carlos for power = ', num2str(Pdb(p)) ,'dB, and per user DoF = ',num2str(d)])
        P_stream = 10^(Pdb(p)/10)/(1*d); % convert from log to linear
        for i = 1:MC

            H = randn(Mr,Mt,K,K);   % generate gaussian i.i.d channels
            U_rand = randn(Mr,d,K); % randomly draw zeroforcing matrices
            V_rand = randn(Mt,d,K); % randomly draw beamforming matrices
            
            %%%%%%%%%%%%%%%%%% nuclear norm %%%%%%%%%%%%%%%%%%
            clear V_l1 U_l1 S_eig J_eig 
            
            [V_l1 U_l1] = nuclear_IA_K_user(H, U_rand, epsilon, iter_nucnorm);
            
            U_l1 = orthogonalize(U_l1); % orthogonalize them
            V_l1 = orthogonalize(V_l1); % orthogonalize them
            [S_eig J_eig] = block_svd(U_l1, H, V_l1); % find useful and interference eigenvalues
            V_l1 = sqrt(P_stream)*V_l1; % amplify transmit beamformers
            DoF_l1(i,p,d) = mean(sum(S_eig>DoF_accuracy,1) - sum(J_eig>DoF_accuracy,1)); % compute DoF
            R_l1(i,p,d)    = rate_K_user_MIMO(K, d, P_stream, U_l1, H, V_l1, 1); % compute sum rate
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%% leakage minimization %%%%%%%%%%%%%
            clear V_l2 U_l2 S_eig J_eig
            [V_l2, U_l2] = leakage_minimization_K_user(H, V_rand, iter_leakmin); % run leakage minimization
            
            U_l2 = orthogonalize(U_l2); % orthogonalize them
            V_l2 = orthogonalize(V_l2); % orthogonalize them
            [S_eig J_eig] = block_svd(U_l2,H,V_l2); % find useful and interference eigenvalues
            V_l2 = sqrt(P_stream)*V_l2; % amplify transmit beamformers
            DoF_l2(i,p,d) = mean(sum(S_eig>DoF_accuracy,1) - sum(J_eig>DoF_accuracy,1)); % compute DoF
            R_l2(i,p,d)    = rate_K_user_MIMO(K, d, P_stream, U_l2, H, V_l2, 1);% compute sum rate
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            %%%%%%%%%%%%%%%%%%%%% max-SINR %%%%%%%%%%%%%%%%%%%
            clear V_l2 U_l2 S_eig J_eig
            [V_sinr, U_sinr] = maxSINR_K_user(H, V_rand, P_stream, iter_maxsinr); % run max-SINR approach
            
            %%%%%% compute normalized max-SINR matrices %%%%%%
            U_sinr = normalize(U_sinr); % orthogonalize them
            V_sinr = normalize(V_sinr); % orthogonalize them
            [S_eig J_eig] = block_svd(U_sinr,H,V_sinr); % find useful and interference eigenvalues
            V_sinr = sqrt(P_stream)*V_sinr; % amplify transmit beamformers
            DoF_sinr(i,p,d) = mean(sum(S_eig>DoF_accuracy,1) - sum(J_eig>DoF_accuracy,1)); % compute DoF
            R_sinr(i,p,d)    = rate_K_user_MIMO(K, d, P_stream, U_sinr, H, V_sinr, 1);% compute sum rate
            %%%% compute orthogonalized max-SINR matrices %%%%
            U_sinr_qr = orthogonalize(U_sinr); % orthogonalize them
            V_sinr_qr = orthogonalize(V_sinr); % orthogonalize them
            V_sinr_qr = sqrt(P_stream)*V_sinr_qr; % amplify transmit beamformers
            DoF_sinr_qr(i,p,d) = mean(sum(S_eig>DoF_accuracy,1) - sum(J_eig>DoF_accuracy,1)); % compute DoF
            R_sinr_qr(i,p,d)    = rate_K_user_MIMO(K, d, P_stream, U_sinr_qr, H, V_sinr_qr, 1);% compute sum rate
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
        end
           display([' '])
    end
end

for i = d_start:dk
%     figure
    hold on
    plot(Pdb, mean(R_l2(:,:,i)),'b')
    plot(Pdb, mean(R_sinr(:,:,i)), 'g')
    plot(Pdb, mean(R_sinr_qr(:,:,i)), 'c')
    plot(Pdb, mean(R_l1(:,:,i)), 'r')
    axis tight
    hold off
end


for i = d_start:dk
    figure
    hold on
    stem(Pdb, mean(DoF_l2(:,:,i)),'b')
    stem(Pdb, mean(DoF_sinr(:,:,i)), 'g')
    stem(Pdb, mean(DoF_l1(:,:,i)),'r')
    hold off
end
